<?php

class Manager extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
        $this->load->library('session');
       /*cache control*/
		$this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
		$this->output->set_header('Pragma: no-cache');

	}
	public function index()
	{
		if($this->session->userdata('manager_login') != 1)
            redirect(base_url() . 'login', 'refresh');
        else
            redirect(base_url() . 'manager/dashboard');
		
	}
	public function checklogin()
	{
		if ($this->session->userdata('manager_login') != 1)
            redirect(base_url(), 'refresh');
	}
	public function dashboard()
	{
		$this->checklogin();
		$page_data['page']  = 'manager/dashboard';
        $page_data['title'] =  'Dashboard';
        $this->load->view("backend/index",$page_data);
	}
	public function company()
	{
		$page_data['page'] 		=	'manager/company';
		$page_data['title'] 	= 	'Manager';
		$page_data['mycompany']	=	$this->managermodel->get_mycompny();
		$this->load->view("backend/index",$page_data);
	}
	public function cases()
	{
		$this->checklogin();
		$page_data['page']  = 'manager/cases';
        $page_data['title'] = 'My All Cases';
        $page_data['cases']	=  $this->managermodel->my_cases();  		
        $this->load->view("backend/index",$page_data);
		
	}
	public function edit_case($case_id)
	{
		$this->checklogin();
		$page_data['page']  = 'manager/edit_case';
        $page_data['title'] = 'Change Case Status';
        $page_data['cases']	=  $this->managermodel->get_case_by($case_id);  		
        $this->load->view("backend/index",$page_data);
	}
	public function update_case($case_id)
	{
		$config = [

                'upload_path'      =>  './upload/',
                'allowed_types'    =>  'jpg|png|gif|jpeg|xlsx|docx|pdf',
                'overwrite'        =>  'TRUE',
                'max_size'         =>   '2048'  
                ];
            $this->load->library('upload',$config);
             if ($this->upload->do_upload()) {
                       // $file=$_FILES['userfile']['name'];

                    $file=$this->upload->data();
                    $image_path = base_url("upload/".$file['file_name']);
                    
                    }
                else{
                     $image_path = $this->input->post('userfile');
                }
		 $data['case_name']		=	$this->input->post('case_name');
		 $data['case_country']	=	$this->input->post('country');
		 $data['status']		=	$this->input->post('case_status');
		 $data['case_comments']	=	$this->input->post('case_comments');
		 $data['case_doc']		=	$image_path;

		    if($this->managermodel->update_case($case_id,$data)) {
					$this->session->set_flashdata('feedback','Case Stauts has been Successfully Change');
                     $this->session->set_flashdata('feedback_class','alert-success');
                }
                else{
                    $this->session->set_flashdata('feedback','Please Try Agian');
                    $this->session->set_flashdata('feedback_class','alert-danger');
                }
                return redirect('manager/cases');	
	}

	public function profile()
	{
		$this->checklogin();
		$page_data['page']  = 'manager/manager_profile';
        $page_data['title'] = 'Profile';
        $this->load->view("backend/index",$page_data);
	}
	public function edit_manager_profile($manager_id)
	{
		$this->checklogin();
		$data['manager_name']		=	$this->input->post('name');
		$data['email']				=	$this->input->post('email');
		$data['password']			=	$this->input->post('password');

		    if($this->managermodel->update_manager_profile($manager_id,$data)) {
					$this->session->set_flashdata('feedback','Your Profiel has been Sussfully Update');
                     $this->session->set_flashdata('feedback_class','alert-success');
                }
                else{
                    $this->session->set_flashdata('feedback','Please Try Agian');
                    $this->session->set_flashdata('feedback_class','alert-danger');
                }
                return redirect('manager/profile');	
	}
}


















?>