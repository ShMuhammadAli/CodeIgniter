<div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8">
            <!-- general form elements -->
            <div class="box box-primary">
                <!-- form start -->
                <?php echo form_open_multipart('admin/managers/create',array('role'=>"form", 'class'=>'validate')); ?>

                    <div class="box-body">
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" class="form-control" name="name" id="name" value="" required="required"/>
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" name="email" id="email" min="3" value="" required>
                            <span id="email-format" class="help">Format: manager@gmail.com</span>
                        </div>
                        <div class="form-group">
                            <label for="phone_no">Phone No</label>
                            <input type="phone_no" name="phone_no" class="form-control" value="" autofocus id="phone_no" placeholder="Phone No">
                            <span id="phoneno-format" class="help">Format: +9234 56789087</span>
                        </div>
                        <div class="form-group">
                            <label for="contactno">Password</label>
                            <input type="password" class="form-control" name="password" id="password" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="documents">upload file</label>
                                <?php echo form_upload(['name'=>'userfile']);?> 
                            <span>Image size < 2MB (zip file not allow) </span>
                        </div>
                    </div>
                    <div class="box-footer">
                        <button type="submit" class="btn btn-block btn-success btn-flat">Create Manager Account</button>
                    </div>
                    <?php echo form_close();?>
            </div>
            <!-- /.box -->

        </div>
    </div>
