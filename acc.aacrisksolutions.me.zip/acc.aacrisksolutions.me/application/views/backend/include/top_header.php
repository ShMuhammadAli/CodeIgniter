<header class="main-header">
    <!-- Logo -->
    <a href="<?php echo base_url($account_type);?>" class="logo">
        <span class="logo-mini"><strong>A</strong>CC</span>
        <span class="logo-lg"><b>Verification</b>System</span>
    </a>
    <nav class="navbar navbar-static-top">
        <a href="<?php echo base_url($account_type);?>" class="sidebar-toggle" data-toggle="push-menu" role="button">
            <span class="sr-only">Toggle navigation</span>
        </a>

        <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
                    <li class="dropdown user user-menu">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                      <?php echo $this->session->userdata('name'); ?>
<!--                         <span class="hidden-xs">Verification System</span>
 -->                    </a>
                    <ul class="dropdown-menu">
                        <!-- User image -->
                        <li class="user-header">
                            <p>
                               Verification System
                                <small>Develop By  Ennovive TECH.2019</small>
                            </p>
                        </li>
                        <li class="user-footer">
                            <div class="pull-left">
                                <a href="<?php echo $account_type.'/'.'profile'; ?>" class="btn btn-default btn-flat">Profile</a>
                            </div>
                            <div class="pull-right">
                                <a href="<?php echo "login/logout"?>" class="btn btn-default btn-flat">Sign out</a>
                            </div>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
    </nav>
</header>