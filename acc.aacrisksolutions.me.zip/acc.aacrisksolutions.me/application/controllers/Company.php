<?php

class Company extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
        $this->load->library('session');
		
       /*cache control*/
		$this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
		$this->output->set_header('Pragma: no-cache');
	}
	public function index()
	{
		if ($this->session->userdata('company_login') != 1)
            redirect(base_url() . 'login', 'refresh');
        else
            redirect(base_url() . 'company/dashboard', 'refresh');
	}
	public function checklogin()
	{
		if ($this->session->userdata('company_login') != 1)
            redirect(base_url(), 'refresh');
	}
	public function dashboard()
	{
		$this->checklogin();
		$page_data['page']  = 'company/dashboard';
        $page_data['title'] =  'Dashboard';
        $this->load->view("backend/index",$page_data);
	}
	
	public function case_information()
	{
		$this->checklogin();
	    $login_user = $this->session->userdata('company_id');
		$page_data['page']  = 'company/case_information';
 	    $page_data['cases'] =   $this->companymodel->company_case($login_user);
        $page_data['title'] =  'Case Info';
        $this->load->view("backend/index",$page_data);
	}
	 public function case_submit()
	{
		$this->checklogin();
		$page_data['page']  		= 'company/add_case';
        $page_data['title'] 		= 'Case Submit';
        $this->load->view("backend/index",$page_data);
	}

	public function cases($param1='',$param2='')
	{
	
		if ($param1== 'create') {

				$config = [

	            'upload_path'      =>  './upload/',
	            'allowed_types'    =>  'jpg|png|gif|jpeg|xlsx|docx|pdf',
	            'overwrite'        =>  'TRUE',
	            'max_size'		   =>	'2048'	
	            ];
        	$this->load->library('upload',$config);
			 if ($this->upload->do_upload()) {
				
				$file=$this->upload->data();
				$image_path = base_url("upload/".$file['file_name']);
				$this->load->helper('string');
				$reference_no  =random_string('numeric',5);                        

						$data['case_name'] 	 		= $this->input->post('case_name');
						$data['case_country'] 		= $this->input->post('case_country');
						$data['case_type_id']	 	= $this->input->post('case_type');
						$data['case_doc'] 	 		= $image_path;
						$data['case_date'] 			= $this->input->post('case_date');
						$data['status']				= "Pending";
						$data['case_no']			= $reference_no;	
						$data['company_id']			= $this->session->userdata('company_id');
 						
			            if($this->db->insert('company_case', $data)) {

			                    $this->session->set_flashdata('feedback','Case Submited');
			                    $this->session->set_flashdata('feedback_class','alert-success');  
			            }
			            else{

			            	$this->session->set_flashdata('feedback','Please Try Again');
			                $this->session->set_flashdata('feedback_class','alert-danger');
			            }
			            redirect(base_url() . 'company/case_information/');
        	}else{
        		redirect(base_url() . 'company/case_submit/');

        	}

		}
		if ($param1 == 'edit') {

			$record 					=  $this->adminmodel->get_case_data($param2);
			$page_data['page']  		= 'company/edit_case';
	        $page_data['title'] 		= 'Update Case status';
	        $page_data['case_data']		=  $record;	
	        $this->load->view("backend/index",$page_data);
			}


			if ($param1 == 'do_update') {

				
        		$config = [

	            'upload_path'      =>  './upload/',
	            'allowed_types'    =>  'jpg|png|gif|jpeg|xlsx|docx|pdf',
	            'overwrite'        =>  'TRUE',
	            'max_size'		   =>	'2048'	
	            ];
        	$this->load->library('upload',$config);
			 if ($this->upload->do_upload()) {
				       // $file=$_FILES['userfile']['name'];

					$file=$this->upload->data();
					$image_path = base_url("upload/".$file['file_name']);
					
					}
				else{
				 	 $image_path = $this->input->post('userfile');
				}

				$data['case_name'] 	 	= $this->input->post('case_name');
				$data['case_country'] 	= $this->input->post('country');
				$data['status'] 		= $this->input->post('case_status');
				$data['case_date']	 	= $this->input->post('case_date');
				$data['case_type_id']	= $this->input->post('case_type');
				$data['case_doc']		= $image_path;


				if($this->adminmodel->update_case_status($param2,$data)) {
						$this->session->set_flashdata('feedback','Company data update Successfully');
	                     $this->session->set_flashdata('feedback_class','alert-success');
	                }
	                else{
	                    $this->session->set_flashdata('feedback','Company Failed To Update, Please Try Agian');
	                    $this->session->set_flashdata('feedback_class','alert-danger');
	                }
	                return redirect('company/case_information/','refresh');	
			}
	

		if ($param1 == 'delete') {
			

			if ($this->companymodel->delete_case($param2)){

            	$this->session->set_flashdata('feedback','Case Deleted Successfully');
                     $this->session->set_flashdata('feedback_class','alert-success');
            }else{
                    $this->session->set_flashdata('feedback','Please Try Agian');
                    $this->session->set_flashdata('feedback_class','alert-danger');
                }




                return redirect('company/case_information/');		
		}
	}

	public function profile()
	{
		$this->checklogin();
		$page_data['page']  = 'company/profile';
        $page_data['title'] = 'Profile';
        $this->load->view("backend/index",$page_data);
	}
	public function edit_company_profile($company_id)
	{
		$this->checklogin();
		$data['company_name']		=	$this->input->post('name');
		$data['email']				=	$this->input->post('email');
		$data['password']			=	$this->input->post('password');

		if($this->companymodel->update_company_profile($company_id,$data)) {
			    $this->session->set_flashdata('feedback','Your Profile has been Sussfully Update');
                $this->session->set_flashdata('feedback_class','alert-success');
            }
            else{
                $this->session->set_flashdata('feedback','Please Try Agian');
                $this->session->set_flashdata('feedback_class','alert-danger');
            }
            return redirect('company/profile');	
	}

}

?>
