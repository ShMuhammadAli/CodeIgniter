<!DOCTYPE html>
<html>
<head>
	<title>Blog</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/bootstrap/css/bootstrap-theme.min.css') ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/bootstrap/css/dataTables.bootstrap.css') ?>">
	<script type="text/javascript" src="<?php echo base_url(); ?>assets/bootstrap/js/jquery-3.1.1.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url(); ?>assets/bootstrap/js/bootstrap.min.js"></script>
	
	<script type="text/javascript" src="<?php echo base_url(); ?>assets/bootstrap/js/dataTables.bootstrap.js"></script>
	<script type="text/javascript" src="<?php echo base_url(); ?>assets/bootstrap/js/jquery.dataTables.js"></script>
</head>
<body>

<div class="navbar navbar-default">
	<div class="container">
		<h2><center><span class="glyphicon glyphicon-home"></span>&nbsp; Codeigniter CRUD Using + Ajax</center></h2>
	</div>
</div>
<div class="container">