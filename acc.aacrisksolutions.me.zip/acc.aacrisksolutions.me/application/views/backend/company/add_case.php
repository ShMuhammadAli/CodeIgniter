<div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8">           
            <!-- general form elements -->
            <div class="box box-primary">
                <!-- form start -->
                <?php echo form_open_multipart('company/cases/create',array('role'=>"form", 'class'=>'validate')); ?>
                    <div class="box-body">
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" class="form-control" name="case_name" id="name" value="" autofocus required="required"/>
                        </div>
                        <div class="form-group">
                            <label for="number">Country</label>
                            <input type="text" class="form-control" name="case_country" id="number" 
                            value=" "/>
                        </div>
                        <div class="form-group">
                            <label>Case Type</label>
                            <select name="case_type" class="form-control select2" style="width: 100%; height: auto;" required>
                                <option value selected disabled>Case Status</option>
                                <?php
                            
                                $query = $this->db->get('case_type');
                                $data  = $query->result();

                                if (count($data)) {
                                    foreach ($data as $case_data) { ?>

                                    <option value="<?php echo $case_data->case_type_id; ?>"><?php echo $case_data->case_type_name?></option>
                                            
                                    <?php }} ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="date">Date</label>
                            <input type="text" class="form-control" name="case_date" id="date" />
                        </div>
                        <div class="form-group">
                            <label for="documents">upload file</label>
                               <?php echo form_upload(['name'=>'userfile']);?> 
                                    <?php  if(isset($upload_error)) { echo "<div style='color:red;>'".$upload_error."</div>"; } ?>  
                            <span>Documents are required | file size < 2MB (zip file not allow) </span>
        
                        </div>
                    </div>
                    <div class="box-footer">
                        <button type="submit" class="btn btn-block btn-success btn-flat">Submit Case</button>
                    </div>
                    <?php echo form_close();?>
            </div>
            <!-- /.box -->

        </div>
    </div>
    <script type="text/javascript">
  //  n =  new Date();
 //y = n.getFullYear(); 
 // m = n.getMonth() + 1;
// d = n.getDate();
// document.getElementById("date").innerHTML = m + "/" + d + "/" + y;
var today = new Date();
var dd = today.getDate();
var mm = today.getMonth()+1; //January is 0!
var yyyy = today.getFullYear();

if(dd<10) {
    dd = '0'+dd
} 

if(mm<10) {
    mm = '0'+mm
} 
today = mm + '/' + dd + '/' + yyyy;
document.getElementById('date').innerHTML = today;
document.getElementById('date').value = today;
</script>