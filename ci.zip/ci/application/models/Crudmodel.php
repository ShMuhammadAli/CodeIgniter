<?php


Class CrudModel extends CI_Model
{
	function __construct()
	{
		parent::__construct();
	}

	public function getAllUsers(){

		$query =$this->db->get('users');
		if ($query->num_rows() >0) {
			return $query->result();
			
		}else{
			return false;
		}
	}

	public function adduser($data)
	{
		$this->db->insert('users',$data);
		if($this->db->affected_rows() > 0){
			return true;
		}else{
			return false;
		}
		
	}

	public function edituser($id)
	{
		$this->db->where('user_id', $id);
		$query = $this->db->get('users');
		if($query->num_rows() > 0){
			return $query->row();
		}else{
			return false;
		}
	}
	public function updateuser()
	{
		$id 						= $this->input->post('userid');
		$data['user_name'] 			= $this->input->post('username');
		$data['user_contact_no']	= $this->input->post('contactno');
		$data['user_age'] 			= $this->input->post('userage');	
		$this->db->where('user_id', $id);
		$this->db->update('users',$data);
		if($this->db->affected_rows() >0){

			return true;
		}else{

			return false;
		}

	}

	function deleteuser(){
		$id = $this->input->get('user_id');
		$this->db->where('user_id', $id);
		$this->db->delete('users');
		if($this->db->affected_rows() > 0){
			return true;
		}else{
			return false;
		}
	}
}