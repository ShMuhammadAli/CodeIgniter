<?php  if($feedback= $this->session->flashdata('feedback')):
                $feedback_class= $this->session->flashdata('feedback_class'); ?>

                <div class="alert alert-dismissible <?= $feedback_class ?>">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <h4><i class="icon fa fa-check"></i><?= $feedback ?></h4>
                </div>
            <?php   endif; ?>

<div class="row">
    <div class="col-xs-12">

        <div class="box">
            <div class="box-header">
                <h3 class="box-title"><?php echo $title;?></h3>
                <div class="btn-group" style="float: right;">
                    <a href="<?php echo base_url();?>admin/add_manager" class="btn btn-success "><i class="fa fa-fw fa-plus-square"></i>Manager Account</a>
                </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                     <tr>
                        <th>Image</th>
                        <th>Manager Name</th>
                        <th>Contact No</th>
                        <th>Email</th>
                        <th>Option</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php
                            if (count($managers)):
                                foreach ($managers as $manager):
                        ?>
                    <tr>
                        <td><img src="<?php echo $manager->manager_pic; ?>" width="40" height="40" title="><?php echo $manager->manager_name; ?>"></td>
                        <td><?php echo $manager->manager_name; ?></td>
                        <td><?php echo $manager->manager_phoneno; ?></td>
                        <td><?php echo $manager->email; ?></td>
                        <td>
                            <div class="btn-group">
                                <?php echo anchor("admin/edit_manger/{$manager->manager_id}",'Edit',['class'=>'btn btn-primary ']); ?>
                            </div>
                            <div class="btn-group">
                                <?php
                                    echo form_open("admin/managers/delete/{$manager->manager_id}");
                                    echo form_hidden('company_id');
                                    echo form_submit(['name'=>'submit','value'=>'Delete','class'=>'btn btn-danger']);
                                    echo form_close();
                                    ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; endif;?>
                    </tbody>
                    <tfoot>
                    <tr>
                        <th>Image</th>
                        <th>Manager Name</th>
                        <th>Contact No</th>
                        <th>Email</th>
                        <th>Option</th>
                    </tr>
                    </tfoot>
                </table>
            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.box -->
    </div>
    <!-- /.col -->
</div>
