<div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8">
            <!-- general form elements -->
            <div class="box box-primary">
                <!-- form start -->
                <?php echo form_open_multipart('admin/managers/do_update/'.$manager->manager_id,array('role'=>"form", 'class'=>'validate')); ?>

                    <div class="box-body">
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" class="form-control" name="name" id="name" value="<?php echo $manager->manager_name; ?>" required="required"/>
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" name="email" id="email" min="3" value="<?php echo $manager->email; ?>" required>
                            <span id="email-format" class="help">Format: manager@gmail.com</span>
                        </div>
                        <div class="form-group">
                            <label for="phone_no">Phone No</label>
                            <input type="phone_no" name="phone_no" class="form-control" value="<?php echo $manager->manager_phoneno; ?>" autofocus id="phone_no" placeholder="Phone No">
                        </div>
                        <div class="form-group">
                            <label for="contactno">Password</label>
                            <input type="password" class="form-control" name="password" id="password" value="<?php echo $manager->password; ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="documents">upload file</label>
                                <?php echo form_upload(['name'=>'userfile']);?> 
                                <input type="hidden"  name="userfile" value="<?php echo $manager->manager_pic; ?>">        
                        </div>  
                    </div>
                    <div class="box-footer">
                        <button type="submit" class="btn btn-block btn-success btn-flat">Update Manager Account</button>
                    </div>
                    <?php echo form_close();?>
            </div>
            <!-- /.box -->
        </div>
    </div>
