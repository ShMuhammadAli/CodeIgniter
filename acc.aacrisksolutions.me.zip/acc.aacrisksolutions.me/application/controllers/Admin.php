<?php

class Admin extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
        $this->load->library('session');
		
       /*cache control*/
		// $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
		// $this->output->set_header('Pragma: no-cache');
	}
	public function index()
	{
		if($this->session->userdata('admin_login') != 1)
            redirect(base_url() . 'login', 'refresh');
        else
            redirect(base_url() . 'admin/dashboard', 'refresh');
	}

	public function checklogin()
	{
		if ($this->session->userdata('admin_login') != 1)
            redirect(base_url(), 'refresh');
	}
	public function dashboard()
	{
		$this->checklogin();
		$page_data['page']  = 'admin/dashboard';
        $page_data['title'] =  'Dashboard';
        $this->load->view("backend/index",$page_data);
	}

	   /***Company Managment***/
	public function create_company()
	{
		$this->checklogin();
		$page_data['page']  = 'admin/create_company';
        $page_data['title'] =  'Create Company';
        $this->load->view("backend/index",$page_data);
	}

	public function company_info()
	{
		$this->checklogin();
		$record 				=  $this->adminmodel->get_all_company();
		$page_data['page']  	= 'admin/company_info';
        $page_data['title'] 	= 'Compay Info';
        $page_data['records']	=  $record;	

        $this->load->view("backend/index",$page_data);
	}

	public function update_company_info($company_id)
	{
		$this->checklogin();
		$record 				=  $this->adminmodel->get_company_data($company_id);
		$page_data['page']  	= 'admin/edit_company_info';
        $page_data['title'] 	= 'Update Company Information';
        $page_data['records']	=  $record;	

        $this->load->view("backend/index",$page_data);

	}

	public function company($param1 = '',$param2 = '', $param3 = '')
	{
		$this->checklogin();
		if ($param1 == "create") {

			$config = [

	            'upload_path'      =>  './upload/',
	            'allowed_types'    =>  'jpg|png|gif|jpeg|xlsx|docx|pdf',
	            'overwrite'        =>  'TRUE',
	            'max_size'		   =>	'2048'	
	            ];
        	$this->load->library('upload',$config);
			 if ($this->upload->do_upload()) {
				
				$file=$this->upload->data();
				$image_path = base_url("upload/".$file['file_name']);
			}else{ $image_path=base_url("upload/user.jpg");}

			$data['company_name'] 	 	= $this->input->post('company_name');
			$data['company_address'] 	= $this->input->post('address');
			$data['company_phoneno'] 	= $this->input->post('phone_no');
			$data['email']		 	 	= $this->input->post('company_email');
			$data['company_represent'] 	= $this->input->post('representative');
			$data['password']		 	= $this->input->post('pass');
			$data['company_logo'] 	 	= $image_path;
			
			if($this->db->insert('company', $data)) {

                    $this->session->set_flashdata('feedback','Company Account crea');
                    $this->session->set_flashdata('feedback_class','alert-success'); 
            }
            else{

            	$this->session->set_flashdata('feedback','Post Failed To Add, Please Try Agian');
                $this->session->set_flashdata('feedback_class','alert-danger');
            }
            redirect(base_url() . 'admin/company_info/', 'refresh');
		}
		// echo $param2;
		
		if ($param1 == "do_update") {
			$config = [

	            'upload_path'      =>  './upload/',
	            'allowed_types'    =>  'jpg|png|gif|jpeg|xlsx|docx|pdf',
	            'overwrite'        =>  'TRUE',
	            'max_size'		   =>	'2048'	
	            ];
        	$this->load->library('upload',$config);
			 if ($this->upload->do_upload()) {
				
				$file=$this->upload->data();
				$image_path = base_url("upload/".$file['file_name']);
			}else{ $image_path=base_url("upload/user.jpg");}

			$data['company_name'] 	 	= $this->input->post('company_name');
			$data['company_address'] 	= $this->input->post('address');
			$data['company_phoneno'] 	= $this->input->post('phone_no');
			$data['email']		 	 	= $this->input->post('company_email');
			$data['company_represent'] 	= $this->input->post('representative');
			$data['password']		 	= $this->input->post('pass');
			$data['company_logo']	 	= $image_path;
            
            if($this->adminmodel->update_comopany($param2,$data)) {
					$this->session->set_flashdata('feedback','Company data update Successfully');
                     $this->session->set_flashdata('feedback_class','alert-success');
                }
                else{
                    $this->session->set_flashdata('feedback','Company Failed To Update, Please Try Agian');
                    $this->session->set_flashdata('feedback_class','alert-danger');
                }
                return redirect('admin/company_info/');		
		}
		if ($param1 == "delete") {

            if ($this->adminmodel->delete_company($param2)) {

            	$this->session->set_flashdata('feedback','Company data update Successfully');
                     $this->session->set_flashdata('feedback_class','alert-success');
            } else{
                    $this->session->set_flashdata('feedback','Company Failed To Update, Please Try Agian');
                    $this->session->set_flashdata('feedback_class','alert-danger');
                }
                return redirect('admin/company_info/','refresh');		
		}
	}

//////////////////////  Manager Managments  ///////////////////

	public function add_manager()
	{
			$this->checklogin();
		$page_data['page']  = 'admin/add_manager';
        $page_data['title'] = 'Create Manager Account';
        $this->load->view("backend/index",$page_data);
	}
	public function managers_list()
	{
		$this->checklogin();
		$page_data['page']  	= 'admin/managers';
        $page_data['title'] 	= 'All Managers List';
        $page_data['managers']	= $this->adminmodel->get_all_managers(); 		
        $this->load->view("backend/index",$page_data);	
	}
	public function edit_manger($manager_id='')
	{
		$this->checklogin();
		$record 				=  $this->adminmodel->edit_manger($manager_id);
		$page_data['page']  	= 'admin/edit_manager';
	    $page_data['title'] 	= 'Edit Manager Information';
	    $page_data['manager']	=  $record;	
        $this->load->view("backend/index",$page_data);
	}

	public function managers($param1='',$param2="")
	{
		if ($param1 == "create") {

					$config = [

		            'upload_path'      =>  './upload/',
		            'allowed_types'    =>  'jpg|png|gif|jpeg|xlsx|docx|pdf',
		            'overwrite'        =>  'TRUE',
		            'max_size'		   =>	'2048'	
		            ];
	        	$this->load->library('upload',$config);
				 if ($this->upload->do_upload()) {
					
					$file=$this->upload->data();
					$image_path = base_url("upload/".$file['file_name']);
				}else{ $image_path=base_url("upload/user.jpg");}

				$data['manager_name'] 	 	= $this->input->post('name');
				$data['email'] 				= $this->input->post('email');
				$data['password'] 			= $this->input->post('password');
				$data['manager_phoneno']	= $this->input->post('phone_no');
				$data['manager_pic']	 	= $image_path;
				if($this->db->insert('managers', $data)) {

	                    $this->session->set_flashdata('feedback','Manager Account Created Sussfully');
	                    $this->session->set_flashdata('feedback_class','alert-success'); 
	            }
	            else{

	            	$this->session->set_flashdata('feedback','Please Try again');
	                $this->session->set_flashdata('feedback_class','alert-danger');
	            }
	            redirect(base_url() . 'admin/managers_list');

		}
		if ($param1 == "do_update") {

			$config = [

	            'upload_path'      =>  './upload/',
	            'allowed_types'    =>  'jpg|png|gif|jpeg|xlsx|docx|pdf',
	            'overwrite'        =>  'TRUE',
	            'max_size'		   =>	'2048'	
	            ];
        	$this->load->library('upload',$config);
			 if ($this->upload->do_upload()) {
				
				$file=$this->upload->data();
				$image_path = base_url("upload/".$file['file_name']);
			}else{ $image_path=base_url("upload/user.jpg");}

			$data['manager_name'] 	 	= $this->input->post('name');
			$data['email'] 				= $this->input->post('email');
			$data['password'] 			= $this->input->post('password');
			$data['manager_phoneno']	= $this->input->post('phone_no');
			$data['manager_pic']	 	= $image_path;

			if($this->adminmodel->update_manager($param2,$data)) {

                    $this->session->set_flashdata('feedback','Manager Account Update Sussfully');
                    $this->session->set_flashdata('feedback_class','alert-success'); 
            }
            else{

            	$this->session->set_flashdata('feedback','Please Try again');
                $this->session->set_flashdata('feedback_class','alert-danger');
            }
            redirect(base_url() . 'admin/managers_list');

			
		}
		if ($param1 == "delete") {

            if ($this->adminmodel->delete_manager($param2)) {

            	$this->session->set_flashdata('feedback','Manager Account Removed');
                     $this->session->set_flashdata('feedback_class','alert-success');
            } else{
                    $this->session->set_flashdata('feedback','Please Try Agian');
                    $this->session->set_flashdata('feedback_class','alert-danger');
                }
                return redirect('admin/managers_list');		
            }
	}

//////////////////// Manager & Company Management //////////////
	public function managers_company()
	{
		$page_data['page']  = 'admin/managers_company';
        $page_data['title'] =  'All Managers Company';
        $page_data['manager_company']	= $this->adminmodel->manager_companies();
        $this->load->view("backend/index",$page_data);
	}

	public function add_manager_company()
	{
		$page_data['page']  = 'admin/add_manager_company';
        $page_data['title'] =  'Assign Company to Manager';
        $this->load->view("backend/index",$page_data);
	}

	public function update_manger_company($mc_id="")
	{
		$page_data['page']  = 'admin/edit_manager_company';
        $page_data['title'] =  'Change Managers Company';
        $page_data['mcomp']	= $this->adminmodel->get_manger_company($mc_id);
        $this->load->view("backend/index",$page_data);		
	}

	public function manager_company($param1="",$param2="",$param3="")
	{
		if ($param1 == "create") {
			
			$data['company_id'] 	 	= $this->input->post('company');
			$data['manager_id'] 	 	= $this->input->post('manager');
			
			if($this->db->insert('manager_company_case', $data)) {

            $this->session->set_flashdata('feedback','Company has been Assinged');
            $this->session->set_flashdata('feedback_class','alert-success'); 
        	}
            else{

            	$this->session->set_flashdata('feedback','Cehck again Re-Assing Company');
                $this->session->set_flashdata('feedback_class','alert-danger');
            }
            redirect(base_url() . 'admin/managers_company');
		}
		if ($param1 == "do_update") {
			
			$data['company_id'] 	 	= $this->input->post('company');
			$data['manager_id'] 	 	= $this->input->post('manager');

			if($this->adminmodel->update_manager_company($data,$param2)) {
					$this->session->set_flashdata('feedback','Manager Company Record Successfully Update');
                     $this->session->set_flashdata('feedback_class','alert-success');
                }
                else{
                    $this->session->set_flashdata('feedback','Failed To Update, Please Try Agian');
                    $this->session->set_flashdata('feedback_class','alert-danger');
                }
                return redirect('admin/managers_company');	

		}
		if ($param1 == "delete") {

            if ($this->adminmodel->delete_manager_company($param2)) {

            	$this->session->set_flashdata('feedback','Delete sussfully');
                     $this->session->set_flashdata('feedback_class','alert-success');
            } else{
                    $this->session->set_flashdata('feedback','Please Try Agian');
                    $this->session->set_flashdata('feedback_class','alert-danger');
                }
                return redirect('admin/managers_company');		
            }
	}

//////////////////////    Case Manamgent By Admin   ///////////////////


	public function case_information()
	{
		$this->checklogin();
		$page_data['page']  = 'admin/case_information';
		$page_data['cases']=   $this->adminmodel->get_cases();
        $page_data['title'] =  'Case Info';
        $this->load->view("backend/index",$page_data);
	}
	public function cases($param1='',$param2='')
	{
		$this->checklogin();

		if ($param1 == 'edit') {
				
			$record 				=  $this->adminmodel->get_case_data($param2);
			$page_data['page']  	= 'admin/edit_case';
	        $page_data['title'] 	= 'Update Case status';
	        $page_data['case_data']	=  $record;	

        	$this->load->view("backend/index",$page_data);
		}
		if ($param1 == 'do_update') {

			$config = [

                'upload_path'      =>  './upload/',
                'allowed_types'    =>  'jpg|png|gif|jpeg|xlsx|docx|pdf',
                'overwrite'        =>  'TRUE',
                'max_size'         =>   '2048'  
                ];
            $this->load->library('upload',$config);
             if ($this->upload->do_upload()) {
                       // $file=$_FILES['userfile']['name'];

                    $file=$this->upload->data();
                    $image_path = base_url("upload/".$file['file_name']);
                    
                    }
                else{
                     $image_path = $this->input->post('userfile');
                }
			
			$data['case_name'] 	 	= $this->input->post('case_name');
			$data['case_country'] 	= $this->input->post('country');
			$data['status'] 		= $this->input->post('case_status');
			$data['case_date'] 		= $this->input->post('case_date');
			$data['case_comments'] 	= $this->input->post('case_comments');
			$data['case_doc']		= 	$image_path;


			if($this->adminmodel->update_case_status($param2,$data)) {
					$this->session->set_flashdata('feedback','Case data update Successfully');
                     $this->session->set_flashdata('feedback_class','alert-success');
                }
                else{
                    $this->session->set_flashdata('feedback','Please Try Agian');
                    $this->session->set_flashdata('feedback_class','alert-danger');
                }
                return redirect('admin/case_information/','refresh');	
		}
	}

/////////////       Manage Profiel        ////////////////////

	public function profile()
	{
		$this->checklogin();
		$page_data['page']  = 'admin/profile';
        $page_data['title'] =  'MY Profile';
        $this->load->view("backend/index",$page_data);
	}
	public function edit_admin_profile($admin_id)
	{
		$this->checklogin();
		$data['name']				=	$this->input->post('name');
		$data['email']				=	$this->input->post('email');
		$data['password']			=	$this->input->post('password');

		    if($this->adminmodel->update_admin_profile($admin_id,$data)) {
					$this->session->set_flashdata('feedback','Your Profiel has been Sussfully Update');
                     $this->session->set_flashdata('feedback_class','alert-success');
                }
                else{
                    $this->session->set_flashdata('feedback','Please Try Agian');
                    $this->session->set_flashdata('feedback_class','alert-danger');
                }
                return redirect('admin/profile');	
	}

}

























?>