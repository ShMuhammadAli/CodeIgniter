<div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8">

            <?php  if($feedback= $this->session->flashdata('feedback')):
                $feedback_class= $this->session->flashdata('feedback_class'); ?>

                <div class="alert alert-dismissible <?= $feedback_class ?>">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <h4><i class="icon fa fa-check"></i>Company Registerd!</h4>
                    <?= $feedback ?>
                </div>
            <?php   endif; ?>
            <!-- general form elements -->
            <div class="box box-primary">
                <!-- form start -->
                <?php echo form_open_multipart('admin/company/create',array('role'=>"form", 'class'=>'validate')); ?>

                    <div class="box-body">

                        <div class="form-group">
                            <label for="number">Name</label>
                            <input type="text" class="form-control" name="company_name" id="number" value="" required="required"/>
                        </div>

                        <div class="form-group">
                            <label for="stdname">Email</label>
                            <input type="email" class="form-control" name="company_email" id="std_name" min="3" value="" placeholder="admin@gmail.com"required>
                            <span id="name-format" class="help">Format: admin@gmail.com</span>
                        </div>

                        <div class="form-group">
                            <label for="phone_no">Phone No</label>
                            <input type="phone_no" name="phone_no" class="form-control" value="" autofocus id="phone_no" placeholder="Phone No">
                            <span id="email-format" class="help">Format: +9234 56789087</span>
                        </div>
                        <div class="form-group">
                            <label for="contactno">Representative</label>
                            <input type="text" class="form-control" name="representative" id="contactno" placeholder="M Ali" required>
                        </div>
                        <div class="form-group">
                            <label for="contactno">Address</label>
                            <input type="text" class="form-control" name="address" id="contactno" placeholder="Multan Pakistan" required>
                        </div>
                        <div class="form-group">
                            <label for="contactno">Password</label>
                            <input type="password" class="form-control" name="pass" id="pass" required>
                        </div>
                         <div class="form-group">
                            <label for="documents">upload file</label>
                                <?php echo form_upload(['name'=>'userfile']);?> 
                            <span>Image size < 2MB (zip file not allow) </span>
                        </div>
                    </div>
                    <div class="box-footer">
                        <button type="submit" class="btn btn-block btn-success btn-flat">Create Company</button>
                    </div>
                    <?php echo form_close();?>
            </div>
            <!-- /.box -->

        </div>
    </div>
