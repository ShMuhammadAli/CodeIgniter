
<!-- Left side column. contains the logo and sidebar -->
<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <!-- Sidebar user panel -->
        <div class="user-panel">
            <div class="pull-right info">
                <p><?php echo $account_type;
                  echo  $this->session->set_userdata('company_name');

                ?></p>
                <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
            <br>
        </div>
    <!-- sidebar menu: : style can be found in sidebar.less -->
        <ul class="sidebar-menu" data-widget="tree">
            <li class="header">MAIN NAVIGATION</li>

            <!-- Dashboar Links -->
            <?php // if($this->session->userdata('login_type') == 'admin' ){?> 
                <!-- <li>
                    <a href="admin/dashboard">
                        <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                    </a>
                </li> -->
        <?php // }elseif($this->session->userdata('login_type') == 'company'){?>
            <li>
                <a href="company/dashboard">
                    <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                </a>
            </li>
       <?php // }elseif($this->session->userdata('login_type') == 'manager' ) { ?>
            <!-- <li>
                <a href="manager/dashboard">
                    <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                </a>
            </li> -->
       <?php // } ?>


       <?php //if($this->session->userdata('login_type') == 'admin'){?>
            <li class="treeview">
                <a href="#">
                    <i class="fa fa-fw fa-users"></i>
                    <span>Company</span>
                    <span class="pull-right-container">
                    <i class="fa fa-angle-left pull-right"></i>

                     </span>
                </a>
                <ul class="treeview-menu">
                    <li>
                        <a href="admin/create_company"><i class="fa fa-circle-o"></i>Create Company</a>
                    </li>
                    <li><a href="admin/company_info"><i class="fa fa-circle-o"></i>Company Info</a></li>
                </ul>
            </li>

        <?php //}?>

<!-- Case Section  -->
<?php //if($this->session->set_userdata('login_type') == 'admin'):?>
            <li>
                <a href="admin/case_information">
                    <i class="fa fa-dashboard"></i> <span>Case Info</span>
                </a>
            </li>

<?php //endif; ?>

            <?php //if($this->session->set_userdata('login_type') == 'company' ) : 
            ?>
            <li class="treeview">
                <a href="#">
                    <i class="fa fa-folder-open"></i>
                    <span>Case</span>
                    <span class="pull-right-container">
                    <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li>
                        <a href="company/case_submit"><i class="fa fa-circle-o"></i>Education Case</a>
                    </li>
                    <li>
                        <a href="company/cases/employee"><i class="fa fa-circle-o"></i>Education Case</a>
                    </li>
                    <li>
                        <a href="company/cases/criminal"><i class="fa fa-circle-o"></i>Criminal Case</a>
                    </li>
                    <li>
                        <a href="company/cases/civil"><i class="fa fa-circle-o"></i>Civil Case</a>
                    </li>
                    <li>
                        <a href="company/cases/directorship"><i class="fa fa-circle-o"></i>Directorship Case</a>
                    </li>
                    <li>
                        <a href="company/cases/id_case"><i class="fa fa-circle-o"></i>ID Case</a>
                    </li>
                
                    <li><a href="company/case_information"><i class="fa fa-circle-o"></i>Case Info</a></li>
                </ul>
            </li>
        <?php //endif; ?>
        <?php //if($this->session->set_userdata('login_type') == 'admin'){?>

            <li>
                <a href="admin/manage_profile">
                    <i class="fa fa-laptop"></i> <span>Account</span>
                </a>
            </li>
        <?php // }else{ ?>

            <li>
                <a href="company/manage_profile">
                    <i class="fa fa-laptop"></i> <span>Account</span>
                </a>
            </li>

        <?php // }?>
            
        </ul>
    </section>
    <!-- /.sidebar -->
</aside>