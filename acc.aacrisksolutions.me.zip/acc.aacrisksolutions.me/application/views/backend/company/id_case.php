<div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8">      

        <!-- general form elements -->
            <div class="box box-primary">
                <!-- form start -->
                <?php echo form_open_multipart('admin/company/create',array('role'=>"form", 'class'=>'validate')); ?>
                    <div class="box-body">
                        <div class="form-group">
                            <label for="number">Name</label>
                            <input type="text" class="form-control" name="company_name" id="number" value="" required="required"/>
                        </div>
                        <div class="form-group">
                            <label for="contryname">Country</label>
                            <input type="text" class="form-control" name="contry" id="std_name" value="" placeholder="Pakistan"required>
                        </div>
                        <div class="form-group">
                            <label for="idtype">ID Type</label>
                            <input type="text" class="form-control" name="idtype" id="std_name" min="3" value="" required>
                        </div>
                        <div class="form-group">
                            <label for="issuedate">Issue Date</label>
                            <input type="date" class="form-control" name="issuedate" id="issuedate" value="" >
                        </div>
                        <div class="form-group">
                            <label for="inputfile">upload file</label>
                            <input type="file" name="file" id="inputfile" required>
                        </div>
                    </div>
                    <div class="box-footer">
                        <button type="submit" class="btn btn-block btn-success btn-flat">Add Case</button>
                    </div>
                    <?php echo form_close();?>
            </div>
            <!-- /.box -->
        </div>
    </div>