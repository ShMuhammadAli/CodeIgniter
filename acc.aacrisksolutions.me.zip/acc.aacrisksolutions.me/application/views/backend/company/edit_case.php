<div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8">           
            <!-- general form elements -->
            <div class="box box-primary">
                <!-- form start -->
                <?php echo form_open_multipart('company/cases/do_update/'.$case_data->case_id,array('role'=>"form", 'class'=>'validate')); ?>

                    <div class="box-body">
                        <div class="form-group">
                            <label for="number">Applicant Name</label>
                            <input type="text" class="form-control" name="case_name" id="number" value="<?php echo $case_data->case_name;?>"/>
                        </div>

                        <div class="form-group">
                            <label for="country">Country</label>
                            <input type="text" class="form-control" name="country" id="Country" value="<?php echo $case_data->case_country;?>" />
                        </div>
                        <div class="form-group">
                            <label for="case_date">Date</label>
                            <input type="text" class="form-control" name="case_date" id="case_date" value="<?php echo $case_data->case_date;?>" />
                        </div>
                        <div class="form-group">
                            <label>Case status</label>
                            <select name="case_status" class="form-control select2" style="width: 100%; height: auto;" required>
                                <option value="<?php echo $case_data->status;?>" selected >
                                    <?php echo $case_data->status;?>
                                        
                                </option>
                                <option value="Vendor opened">Vendor opened</option>
                                <option value="Vendor Partially Completed">Vendor Partially Completed
                                </option>
                                <option value="Vendor Partially Completed">Insufficiency</option>
                                <option value="Pending">Pending</option>
                                <option value="Close">Close</option>
                                <option value="Re - Assigned">Re - Assigned</option>
                                <option value="Insufficiency Cleared">Insufficiency Cleared</option>
                                <option value="Insufficiency Vendor">Insufficiency Vendor</option>
                                <option value="Vendor Completed">Vendor Completed</option>
                                <option value="Insufficiency Clerr Vendor">Insufficiency Clear Vendor</option>
                            </select>
                        </div>
                         <div class="form-group">
                            <label>Case Type</label>
                            <select name="case_type" class="form-control select2" style="width: 100%; height: auto;" required>
                                <option value selected disabled>Case Status</option>
                                <?php
                                
                                $query = $this->db->get('case_type');
                                $data  = $query->result();
                                if (count($data)):
                                    foreach ($data as $case): ?>
                                    <option value="<?php echo $case->case_type_id; ?>" 
                                        <?php if($case->case_type_id == $case_data->case_type_id){?>
                                            selected="selected"<?php } ?> > 
                                               <?php echo $case->case_type_name; ?> 
                                    </option>
                                    <?php endforeach; endif; ?>
                            </select>
                        </div> 
                        <div class="form-group">
                            <label for="documents">upload file</label>
                                <?php echo form_upload(['name'=>'userfile']);?> 
                                <input type="hidden"  name="userfile" value="<?php echo $case_data->case_doc; ?>">
                            <span>Documents are required | file size < 2MB (zip file not allow) </span>
        
                        </div>                      
                    </div>
                    <div class="box-footer">
                        <button type="submit" class="btn btn-block btn-success btn-flat">Update Case Status</button>
                    </div>
                    <?php echo form_close();?>
            </div>
            <!-- /.box -->
        </div>
    </div>
