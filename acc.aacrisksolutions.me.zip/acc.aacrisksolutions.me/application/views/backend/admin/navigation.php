<!-- Left side column. contains the logo and sidebar -->
<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <!-- Sidebar user panel -->
        <div class="user-panel">
            <div class="pull-right info">
                <p><?php echo $account_type;?></p>
                <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
            <br>
        </div>
    <!-- sidebar menu: : style can be found in sidebar.less -->
        <ul class="sidebar-menu" data-widget="tree">
            <li class="header">MAIN Manue</li>

            <li>
                <a href="admin/dashboard">
                    <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                </a>
            </li>
    
            <li class="treeview">
                <a href="#">
                    <i class="fa fa-fw fa-users"></i>
                    <span>Company</span>
                    <span class="pull-right-container">
                    <i class="fa fa-angle-left pull-right"></i>

                     </span>
                </a>
                <ul class="treeview-menu">
                    <li>
                        <a href="admin/create_company"><i class="fa fa-circle-o"></i>Create Company</a>
                    </li>
                    <li><a href="admin/company_info"><i class="fa fa-circle-o"></i>Company Info</a></li>
                </ul>
            </li>
            <li class="treeview">
                <a href="#">
                    <i class="fa fa-fw fa-users"></i>
                    <span>Managers</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li>
                        <a href="admin/add_manager"><i class="fa fa-circle-o"></i>ADD Managers</a>
                    </li>
                    <li><a href="admin/managers_list"><i class="fa fa-circle-o"></i>Manager Info</a></li>
                </ul>
            </li>
            <li>
                <a href="admin/managers_company">
                    <i class="fa fa-fw fa-users"></i> <span>Manager Company</span>
                </a>
            </li>
            <li>
                <a href="admin/case_information">
                    <i class="fa fa-book"></i> <span>Case Info</span>
                </a>
            </li> 
            <li>
                <a href="admin/profile">
                    <i class="fa fa-laptop"></i> <span>Account</span>
                </a>
            </li>         
        </ul>
    </section>
    <!-- /.sidebar -->
</aside>