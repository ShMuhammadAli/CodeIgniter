<?php $id = $this->session->userdata('company_id'); ?>
    <!-- Main content -->
    <section class="content">
        <!-- Small boxes (Stat box) -->
      <div class="row">
             <div class="col-lg-3 col-xs-6">
                <!-- small box -->
                <a href="<?php echo base_url();?>company/case_information" title="View All Cases">
                    <div class="small-box bg-aqua">
                        <div class="inner">
                            <h3> <?php $id = $this->session->userdata('company_id'); ?>

                            <?php echo $this->db->where('company_id',$id)->count_all_results('company_case');?></h3>
                            <p> Total Cases</p>
                        </div>
                        <div class="icon">
                            <i class="fa fa-book"></i>
                        </div>
                    </div>
                </a>
            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-xs-6">
                <!-- small box -->
                <a href="<?php echo base_url();?>company/case_information">
                    <div class="small-box bg-green">
                        <div class="inner">
                            <h3><?php $query = $this->db->query('SELECT * FROM company_case where status="Re - Assigned" AND company_id='.$id);
                                echo $query->num_rows();?></h3>
                            <p>Re- Assigned Cases</p>
                        </div>
                        <div class="icon">
                            <i class="fa fa-book"></i>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-lg-3 col-xs-6">
                <!-- small box -->
               <a href="<?php echo base_url();?>company/case_information" title="View All Close Cases">

                    <div class="small-box bg-yellow">
                        <div class="inner">
                             <h3><?php echo $this->db->where(array('status'=>'Close','company_id'=>$id))->count_all_results('company_case');?></h3>

                            <p>Close Case</p>
                        </div>
                        <div class="icon">
                            <i class="fa fa-book"></i>
                        </div>
                    </div>
                </a>
            </div>
             <div class="col-lg-3 col-xs-6">
                <!-- small box -->
                <a href="<?php echo base_url();?>company/case_information" title="View All Pending Cases">

                    <div class="small-box bg-red">
                        <div class="inner">
                            <h3><?php echo $this->db->where(array('status' => "Pending",'company_id' => $id))->count_all_results('company_case');?></h3>
                            <p>Pending Cases</p>
                        </div>
                        <div class="icon">
                            <i class="fa fa-book"></i>                    
                        </div>
                    </div>
                </div>
            </a>
            <!-- ./col -->
        </div>
    
        <!-- /.row -->
    </section>
    <!-- /.content -->
