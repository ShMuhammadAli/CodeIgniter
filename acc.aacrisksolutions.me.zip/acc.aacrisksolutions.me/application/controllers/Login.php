<?php

class Login extends CI_Controller
{
	
	function __construct()
	{
        parent::__construct();
        $this->load->library('session');
        /* cache control */
        $this->output->set_header('Last-Modified: ' . gmdate("D, d M Y H:i:s") . ' GMT');
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
        $this->output->set_header('Pragma: no-cache');
        $this->output->set_header("Expires: Mon, 26 Jul 2020 05:00:00 GMT");
	}

   public function index(){

        if ($this->session->userdata('admin_login') == 1)
            redirect(base_url() . 'admin/dashboard', 'refresh');

        if ($this->session->userdata('compnay_login') == 1)
            redirect(base_url() . 'company/dashboard', 'refresh');

        if ($this->session->userdata('manager_login') == 1)
            redirect(base_url() . 'manager/dashboard', 'refresh');

        $this->load->view('backend/login');
    }
 
    public function user_login()
    {
    	if ($this->form_validation->run('login')) {
    		
    		$password       = $this->input->post('password');
        	$email    		= $this->input->post('email');
       	   $this->validate_login($email, $password);



       }else{

       	$this->session->set_flashdata('login_faild', 'Invalid Username/Passowrd');
        redirect('login/index');
       }
    }

    public function validate_login($email, $password)
    {

    	$credential = array('email' => $email, 'password' => $password);
        $query      = $this->db->get_where('admin', $credential);

            if ($query->num_rows() > 0) {

                $row = $query->row();
                $this->session->set_userdata('admin_login', '1');
                $this->session->set_userdata('admin_id', $row->admin_id);
                $this->session->set_userdata('login_user_id', $row->admin_id);
                $this->session->set_userdata('name', $row->name);
                $this->session->set_userdata('email', $row->email);
                $this->session->set_userdata('password', $row->password);
                $this->session->set_userdata('login_type', 'admin');
                redirect(base_url() . 'admin/dashboard', 'refresh');
            
            }
	        
	        $query = $this->db->get_where('company',$credential);
	        if ($query->num_rows() > 0) {
	            $row = $query->row();
	            $this->session->set_userdata('company_login', '1');
	            $this->session->set_userdata('company_id', $row->company_id);
	            $this->session->set_userdata('login_user_id', $row->company_id);
	            $this->session->set_userdata('name', $row->company_name);
                $this->session->set_userdata('email', $row->email);
                $this->session->set_userdata('password', $row->password);
	            $this->session->set_userdata('login_type', 'company');
	            redirect(base_url() . 'company/dashboard', 'refresh');
	        }

         	$query = $this->db->get_where('managers', $credential);
	        if ($query->num_rows() > 0){
	           $row = $query->row();
	            $this->session->set_userdata('manager_login', '1');
	            $this->session->set_userdata('manager_id', $row->manager_id);
	            $this->session->set_userdata('login_user_id', $row->manager_id);
	            $this->session->set_userdata('name', $row->manager_name);
                $this->session->set_userdata('manager_email', $row->email);
                $this->session->set_userdata('manager_password', $row->password);
	            $this->session->set_userdata('login_type', 'manager');
	            redirect(base_url() . 'manager/index', 'refresh');
	        }
    }


     /*     * *****LOGOUT FUNCTION ****** */

    function logout() {
        $this->session->sess_destroy();
        $this->session->set_flashdata('logout_notification', 'logged_out');
        redirect(base_url());
    }

}

?>