<?php 

class ManagerModel extends CI_Model
{
	function __construct()
	{
		parent::__construct();
	}
	public function get_mycompny()
	{
		$id = $this->session->userdata('manager_id');
		$this->db->select('ennovive.manager_company_case.manager_id,
    					    ennovive.manager_company_case.company_id,
    						ennovive.company.company_name,
    						ennovive.company.company_represent,
    						ennovive.manager_company_case.mcs_id');
		$this->db->from('ennovive.manager_company_case');
		$this->db->join('ennovive.company', 'ennovive.manager_company_case.company_id = ennovive.company.company_id');
		$this->db->where('ennovive.manager_company_case.manager_id',$id);
		 $query = $this->db->get();
        return $query->result();
	}
	public function my_cases()
	{
		$id = $this->session->userdata('manager_id');
		$this->db->select('ennovive.company_case.case_name,
						    ennovive.company_case.case_country,
						    ennovive.company_case.case_id,
						    ennovive.company_case.case_date,
						    ennovive.company_case.status,
						    ennovive.company_case.case_comments,
						    ennovive.company_case.company_id,
						    ennovive.company.company_name,
						    ennovive.manager_company_case.manager_id,
						    ennovive.case_type.case_type_name,
    						ennovive.company_case.case_type_id,
    						ennovive.company_case.case_doc,
    						ennovive.company_case.case_no,
						    ennovive.manager_company_case.company_id');
		$this->db->from('ennovive.company_case ');
		$this->db->join('ennovive.company','On ennovive.company_case.company_id = ennovive.company.company_id');
		$this->db->join('ennovive.manager_company_case','ennovive.manager_company_case.company_id = ennovive.company.company_id');
		$this->db->join('ennovive.case_type','ennovive.company_case.case_type_id = ennovive.case_type.case_type_id');
		$this->db->where('ennovive.manager_company_case.manager_id',$id);
		 $query = $this->db->get();
        return $query->result();
	}
	public function get_case_by($case_id)
	{
		$query = $this->db->where('case_id',$case_id)->get('company_case');
            if ($query->num_rows() >0) {
                    
                    return  $query->row();
            }
	}
	public function update_case($case_id,$case_data)
	{
        return   $this->db->set($case_data,FALSE)->where('case_id',$case_id)->update('company_case');
	}
	public function update_manager_profile($manager_id,$manager_data)
	{
		return   $this->db->set($manager_data,FALSE)->where('manager_id',$manager_id)->update('managers');

	}

}






 ?>