<div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8">      

        <!-- general form elements -->
            <div class="box box-primary">
                <!-- form start -->
                <?php echo form_open_multipart('admin/company/create',array('role'=>"form", 'class'=>'validate')); ?>
                    <div class="box-body">
                        <div class="form-group">
                            <label for="number">Name</label>
                            <input type="text" class="form-control" name="company_name" id="number" value="" required="required"/>
                        </div>
                        <div class="form-group">
                            <label for="stdname">Passport/ id</label>
                            <input type="email" class="form-control" name="company_email" id="std_name" min="3" value="" placeholder="1342"required>
                        </div>
                        <div class="form-group">
                            <label for="stdname">Address</label>
                            <input type="email" class="form-control" name="company_email" id="std_name" min="3" value="" placeholder="Multan"required>
                        </div>
                        <div class="form-group">
                            <label for="stdname">Country</label>
                            <input type="email" class="form-control" name="company_email" id="std_name" min="3" value="" placeholder="admin@gmail.com"required>
                        </div>
                        <div class="form-group">
                            <label for="contactno">upload file</label>
                            <input type="file" name="logo" id="logo" placeholder="+92330153845556" required>
                        </div>
                    </div>
                    <div class="box-footer">
                        <button type="submit" class="btn btn-block btn-success btn-flat">Add Case</button>
                    </div>
                    <?php echo form_close();?>
            </div>
            <!-- /.box -->



        </div>
    </div>