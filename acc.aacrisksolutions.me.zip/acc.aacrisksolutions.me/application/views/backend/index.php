<?php $account_type       = $this->session->userdata('login_type'); ?>

<?php include'include/head.php';?>

<!--    top header area -->
<?php include 'include/top_header.php';?>

<!--    side navigation bar-->
<?php include $account_type.'/'.'navigation.php';?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
           <?php echo $title; ?>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo base_url($account_type);?>"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active"><?php echo $title; ?></li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <!-- Main content -->
        <section class="content container-fluid">

            <?php $this->load->view('backend/'.$page); ?>

        </section>
        <!-- /.content -->

    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->

        <!-- footer area start from here -->
<?php include'include/footer.php';?>



