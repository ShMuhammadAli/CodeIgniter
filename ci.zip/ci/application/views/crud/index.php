<h2>Users Records</h2>

<div class="btn-group" role="group" aria-label="Button group with nested dropdown">
  <button id="adduser" type="button" class="btn btn-success">Add User</button>
  
</div>
<br/>
<br/>
<div class="container">
	<div class="alert alert-success" style="display: none;">
		
	</div>
<table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
               
                <th>Name</th>
                <th>Age</th>
                <th>Contact NO</th>
                <th>Acetion</th>
            </tr>
        </thead>
        <tbody id="showdata">
            
            <!--  get data from ajax request -->
          
        </tbody>
        <tfoot>
            <tr>
                <th>Name</th>
                <th>Age</th>
                <th>Conact No</th>
                <th>Action</th>
            </tr>
        </tfoot>
    </table>

    <!--  Add user Model -->

    <div id="addmodel" class="modal fade" tabindex="-1" role="dialog">
	  	<div class="modal-dialog" role="document">
		    <div class="modal-content">
		      <div class="modal-header">
		        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		        <h4 class="modal-title"></h4>
		      </div>
		      <div class="modal-body">
		        <form id="addForm" action="" method="post" class="form-horizontal">
		        	<input type="hidden" name="userid" value="0">
		        	<div class="form-group">
		        		<label for="username" class="label-control col-md-4">Name</label>

		        		<div class="col-md-6">
		        			<input type="text" name="username" placeholder="Ali" class="form-control" />
		        		</div>
		        	</div>
		        	<div class="form-group">
		        		<label for="userage" class="label-control col-md-4">Age</label>

		        		<div class="col-md-6">
		        			<input  type="text" placeholder="22" name="userage" class="form-control" />
		        		</div>
		        	</div>
		        	<div class="form-group">
		        		<label for="contactno" class="label-control col-md-4">Contact No</label>

		        		<div class="col-md-6">
		        			<input type="text" name="contactno" placeholder="+923156861126" class="form-control" />
		        		</div>
		        	</div>
		        	
		        </form>

		      </div>
		      <div class="modal-footer">
		        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		        <button type="button" id="btnSave" class="btn btn-success" >Save </button>
		      </div>
		    </div><!-- /.modal-content -->
		</div><!-- /.modal-dialog -->
	</div><!-- /.modal -->


	<!-- --------------- Delete Model ---- -->

	<div id="deleteModal" class="modal fade" tabindex="-1" role="dialog">
		  <div class="modal-dialog" role="document">
		    <div class="modal-content">
		      <div class="modal-header">
		        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		        <h4 class="modal-title">Confirm Delete</h4>
		      </div>
		      <div class="modal-body">
		        	Do you want to delete this record?
		      </div>
		      <div class="modal-footer">
		        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		        <button type="button" id="btnDelete" class="btn btn-danger">Delete</button>
		      </div>
		    </div><!-- /.modal-content -->
		  </div><!-- /.modal-dialog -->
		</div><!-- /.modal -->


<!-- -------------------- End of Delete Model------------------------- -->

<!--  Jquery & Ajax Code start from here -->

<script type="text/javascript">

$(function(){

		showUsers(); // function call for view user details into table

		// $('#adduser').modal('show');

		$('#adduser').click(function(){

			$('#addmodel').modal('show');
			$('#addmodel').find('.modal-title').text('Add User');
			$('#addForm').attr('action', '<?php echo base_url() ?>crud/adduser');

		});

	// Modal Js

	$('#btnSave').click(function(){

		var url = $('#addForm').attr('action');
		var data = $('#addForm').serialize(); // get data int serialize form 

		// ----------------- Add User  From Validation  ------------------

		var username 	= $('input[name=username]');
		var userage 	= $('input[name=userage]');
		var contactno 	= $('input[name=contactno]');

		var result = '';

		if (username.val() == ""){
			username.parent().parent().addClass('has-error');
		}else{
			username.parent().parent().removeClass('has-error');
			result +='1';

		}

		if (userage.val() == ""){
			userage.parent().parent().addClass('has-error');
		}else{
			userage.parent().parent().removeClass('has-error');
			result +='2';

		}
		if (contactno.val() == ""){
			contactno.parent().parent().addClass('has-error');
		}else{
			contactno.parent().parent().removeClass('has-error');
			result +='3';

		}

	// -----------------------------------------------------  

		if (result == '123') {

			$.ajax({

				type: 'ajax',
				method: 'post',
				url: url,
				data: data,
				async: false,
				dataType: 'json',
				success: function(response){

					if(response.success){
						console.log(response);
						$('#addmodel').modal('hide');
						$('#addForm')[0].reset();
						if(response.type == 'add'){

							var type = 'added'
						}else if(response.type=='update'){
							var type = "updated"

						}

						$('.alert-success').html('User  successfully').fadeIn().delay(2500).fadeOut('slow');

							showUsers();

					}
					else{

						alert('Try Again');

					}
					
				},
				error: function(){

					alert('Please try Again Could not add data');
				}

			});

		}


		
	});

	// End of Add User Using Jquery Ajax


	// Edit User Section 

	$('#showdata').on('click','.item-edit', function(){

			var  id = $(this).attr('data');
			$('#addmodel').modal('show');
			$('#addmodel').find('.modal-title').text('Edit User Data');
			$('#addForm').attr('action', '<?php echo base_url();?>crud/updateuser');
			
			$.ajax({

				type: 'ajax',
				method: 'get',
				url: '<?php echo base_url();?>crud/edituser',
				data: {user_id: id},
				async: false,
				dataType: 'json',
				success: function(data){
					
					$('input[name=username]').val(data.user_name);
					$('input[name=userage]').val(data.user_age);
					$('input[name=contactno]').val(data.user_contact_no);
					$('input[name=userid]').val(data.user_id);


				},
				error: function(){

					alert('You Could not Edit Data ');
				}


			});
			// alert(id);

	});



	// End Edit User Section

	// -----------------------Delete Section Start From Here ----------------------------------

	//delete- 
		$('#showdata').on('click', '.item-delete', function(){
			var id = $(this).attr('data');
			$('#deleteModal').modal('show');
			
			$('#btnDelete').unbind().click(function(){
				$.ajax({
					type: 'ajax',
					method: 'get',
					async: false,
					url: '<?php echo base_url() ?>crud/deleteuser',
					data:{user_id:id},
					dataType: 'json',
					success: function(response){
						if(response.success){
							$('#deleteModal').modal('hide');
							$('.alert-success').html('User Deleted successfully').fadeIn().delay(4000).fadeOut('slow');
							showUsers();
						}else{
							alert('Error');
						}
					},
					error: function(){
						alert('Error deleting');
					}
				});
			});
		});

	



	// -------------------------- Delete Section End Here -------------------------------------


// Method to show data into table
	function showUsers() {
		
		$.ajax({
			type: 'ajax',
			url: '<?php echo base_url();?>crud/showAllusers',
			async: false,
			dataType: 'json',
			success: function(data){
				var html = '';
				for (var i =0; i<data.length; i++) {
					html += '<tr>' +
			                '<td>'+data[i].user_name+'</td>'+
			                '<td>'+data[i].user_age+'</td>'+
			                '<td>'+data[i].user_contact_no+'</td>'+
			                '<td>'+
								'<a href="javascript:;" class="btn btn-info item-edit" data="'+data[i].user_id+'">Edit</a>'+ ' '+
								'<a href="javascript:;" class="btn btn-danger item-delete" data="'+data[i].user_id+'">Delete</a>'+
							'</td>'+
		            	'</tr>';

				}
				$('#showdata').html(html);
				// console.log(data);
			},
			error: function(){

				alert('Record Not Found');
			}
		});

	}
});

</script>