<?php
defined('BASEPATH') OR exit('No direct script access allowed');


Class Crud extends CI_Controller{
	
	function __construct(){
		parent:: __construct();
		$this->load->model('crudmodel');

	}

	public function index()
	{
		$this->load->view('layout/header');
		$this->load->view('crud/index');
		$this->load->view('layout/footer');
	}
	public function showAllusers()
	{
		$result = $this->crudmodel->getAllUsers();
		echo json_encode($result);
		
	}
	public function adduser()
	{
		$data['user_name'] 			= $this->input->post('username');
		$data['user_contact_no']	= $this->input->post('contactno');
		$data['user_age'] 			= $this->input->post('userage');

		$result = $this->crudmodel->adduser($data);
		$response['success'] 		= false;
		$response['type']			= 'add';

		if($result){
			$response['success'] 	= true;

		}
		echo json_encode($response);
		
	}

	
	public function edituser(){
		$id = $this->input->get('user_id');
		$result = $this->crudmodel->edituser($id);
		echo json_encode($result);
	}

	public function updateuser()
	{
		
		$result 					= $this->crudmodel->updateuser(); 
		$response['success']		= false;
		$response['type']			= 'update';

		if ($result) {
				$response['success'] = true;	

			}	
		echo json_encode($response);
	}
	public function deleteuser(){

		$result = $this->crudmodel->deleteuser();
		$response['success'] = false;
		if($result){
			$response['success'] = true;
		}
		echo json_encode($response);
	}
}