<!-- Left side column. contains the logo and sidebar -->
<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <!-- Sidebar user panel -->
        <div class="user-panel">
            <div class="pull-right info">
                <p><?php echo $account_type;?></p>
                <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
            <br>
        </div>
    <!-- sidebar menu: : style can be found in sidebar.less -->
        <ul class="sidebar-menu" data-widget="tree">
            <li class="header">MAIN NAVIGATION</li>
            <!-- Dashboar Links -->
            <li>
                <a href="manager/dashboard">
                    <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                </a>
            </li>
            <li>
                <a href="manager/company"><i class="fa fa-fw fa-users"></i>My Company</a>
            </li>
            <li>
                <a href="manager/cases"><i class="fa fa-folder-open"></i>My Case</a>
            </li>  
            <li>
                <a href="manager/profile">
                    <i class="fa fa-laptop"></i> <span>Account</span>
                </a>
            </li>           
        </ul>
    </section>
    <!-- /.sidebar -->
</aside>