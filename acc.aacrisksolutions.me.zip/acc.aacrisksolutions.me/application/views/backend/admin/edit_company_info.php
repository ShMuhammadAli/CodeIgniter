<div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8">

            <?php  if($feedback= $this->session->flashdata('feedback')):
                $feedback_class= $this->session->flashdata('feedback_class'); ?>

                <div class="alert alert-dismissible <?= $feedback_class ?>">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <h4><i class="icon fa fa-check"></i>Company Detials Update Successfully!</h4>
                    <?= $feedback ?>
                </div>
            <?php   endif; ?>
            <!-- general form elements -->
            <div class="box box-primary">
                <!-- form start -->
                <?php echo form_open_multipart('admin/company/do_update/'. $records->company_id,array('role'=>"form", 'class'=>'validate')); ?>

                    <div class="box-body">

                        <div class="form-group">
                            <label for="number">Name</label>
                            <input type="text" class="form-control" name="company_name" id="number" value="<?php echo $records->company_name; ?>" required="required"/>
                        </div>

                        <div class="form-group">
                            <label for="stdname">Email</label>
                            <input type="email" class="form-control" name="company_email" id="company_email" value="<?php echo $records->email; ?>" 
                            required>
                            <span id="name-format" class="help">Format: admin@gmail.com</span>
                        </div>

                        <div class="form-group">
                            <label for="phone_no">Phone No</label>
                            <input type="phone_no" name="phone_no" class="form-control" value="<?php echo $records->company_phoneno; ?>" autofocus id="phone_no" placeholder="Phone No">
                            <span id="email-format" class="help">Format: +9234 56789087</span>
                        </div>
                        <div class="form-group">
                            <label for="contactno">Representative</label>
                            <input type="text" class="form-control" name="representative" id="contactno" value="<?php echo $records->company_represent; ?>" >
                        </div>
                        <div class="form-group">
                            <label for="contactno">Address</label>
                            <input type="text" class="form-control" name="address" id="contactno"  value="<?php echo $records->company_address; ?>" >
                        </div>
                        <div class="form-group">
                            <label for="contactno">Password</label>
                            <input type="text" class="form-control" name="pass" id="pass" value="<?php echo $records->password; ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="documents">upload file</label>
                                <?php echo form_upload(['name'=>'userfile']);?> 
                                <input type="hidden"  name="userfile" value="<?php echo  $records->company_logo; ?>">
                        </div> 
                    </div>
                    <div class="box-footer">
                        <button type="submit" class="btn btn-block btn-success btn-flat">Update Company Info</button>
                    </div>
                    <?php echo form_close();?>
            </div>
            <!-- /.box -->

        </div>
    </div>
