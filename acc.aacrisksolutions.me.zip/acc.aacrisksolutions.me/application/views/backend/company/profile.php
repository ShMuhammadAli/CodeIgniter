<?php $id = $this->session->userdata('company_id'); ?>
 <?php  if($feedback= $this->session->flashdata('feedback')):
                $feedback_class= $this->session->flashdata('feedback_class'); ?>

                <div class="alert alert-dismissible <?= $feedback_class ?>">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <h4>    <i class="icon fa fa-check"></i>
                            <?= $feedback ?>
                    </h4>
                </div>
            <?php   endif; ?>
<div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8">           
            <!-- general form elements -->
            <div class="box box-primary">
                <!-- form start -->
                 <?php echo form_open('company/edit_company_profile/'.$id,array('role'=>"form", 'class'=>'validate')); ?>
                <form class="validate">
                    <div class="box-body">
                         <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" class="form-control" name="name" 
                            id="name" value="<?php echo $this->session->userdata('name'); ?>"/>
                        </div>
                        <div class="form-group">
                            <label for="country">Email</label>
                            <input type="email" class="form-control" name="email" 
                            id="email" value="<?php echo $this->session->userdata('email'); ?>" />
                        </div>
                        <div class="form-group">
                            <label for="country">Password</label>
                            <input type="password" class="form-control" name="password" id="password"
                             value="<?php echo $this->session->userdata('password'); ?>" />
                        </div>               
                    </div>
                    <div class="box-footer">
                        <button type="submit" class="btn btn-block btn-success btn-flat">Update Profile</button>
                    </div>
                    <?php echo form_close();?>
            </div>
            <!-- /.box -->

        </div>
    </div>
