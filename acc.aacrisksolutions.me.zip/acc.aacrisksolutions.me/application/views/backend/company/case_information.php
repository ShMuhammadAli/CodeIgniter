 <?php  if($feedback= $this->session->flashdata('feedback')):
                $feedback_class= $this->session->flashdata('feedback_class'); ?>

                <div class="alert alert-dismissible <?= $feedback_class ?>">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <h4><i class="icon fa fa-check"></i>
                    <?= $feedback ?></h4>
                </div>
            <?php   endif; ?>
<div class="row">
    <div class="col-xs-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title"><?php echo $title;?></h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                    <tr>
                        <th>Case Title</th>
                        <th>Country</th>
                        <th>Date</th>
                        <th>Case Type</th>
                        <th>Status</th>
                        <th>Documents</th>
                        <th>Case Code</th>
                        <th>Option</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php 

                        if(count($cases)): 
                            foreach ($cases as $case):?>
                    <tr>
                        <td><?php echo $case->case_name; ?></td>
                        <td><?php echo $case->case_country; ?></td>
                        <td><?php echo $case->case_date; ?></td>
                        <td><?php echo $case->case_type_name; ?></td>
                         <?php if($case->status == "Approved")
                                { $color="#0DE50D";}else{$color="#e50d0d";} ?>
                                <td style="color:<?php echo $color;?>"><?php  echo $case->status; ?></td>
                        <td><a href="<?php echo $case->case_doc;?>" download="">Download</a></td>
                        <td> <?php echo $case->case_no;?></td>
                        <td>
                            <div class="btn-group">
                                <?php echo anchor("company/cases/edit/{$case->case_id}",'Edit',['class'=>'btn btn-primary ']); ?>
                            </div>
                             <div class="btn-group">
                                <?php
                                $case->case_id;
                                    echo form_open("company/cases/delete/{$case->case_id}");
                                    echo form_hidden('case_id');
                                    echo form_submit(['name'=>'submit','value'=>'Delete','class'=>'btn btn-danger']);
                                    echo form_close();
                                    ?>
                            </div> 
                        </td>
                    </tr>
                <?php endforeach; endif;?>
                    </tbody>
                    <tfoot>
                    <tr>
                        <th>Case Title</th>
                        <th>Country</th>
                        <th>Date</th>
                        <th>Case Type</th>
                        <th>Status</th>
                        <th>Documents</th>
                        <th>Case Code</th>
                        <th>Option</th>
                    </tr>
                    </tfoot>
                </table>
            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.box -->
    </div>
    <!-- /.col -->
</div>

