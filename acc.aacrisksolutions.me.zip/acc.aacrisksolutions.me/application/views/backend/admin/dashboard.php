
    <!-- Main content -->
    <section class="content">
        <!-- Small boxes (Stat box) -->
      <div class="row">
            <div class="col-lg-3 col-xs-6">
                <!-- small box -->
                <a href="<?php echo base_url();?>admin/company_info" title="View All Companies List">
                    <div class="small-box bg-aqua">
                        <div class="inner">
                            <h3><?php echo $this->db->count_all('company');?></h3>
                            <p>Companies</p>
                        </div>
                        <div class="icon">
                            <i class="fa fa-fw fa-users"></i>
                        </div>
                    </div>
                </a>
            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-xs-6">
                <!-- small box -->
                <a href="<?php echo base_url();?>admin/managers_list" title="View All Managers List">
                    <div class="small-box bg-green">
                        <div class="inner">
                            <h3><?php echo $this->db->count_all('managers');?></h3>
                            <p>All Managers</p>
                        </div>
                        <div class="icon">
                            <i class="ion ion-person-add"></i>
                        </div>
                    </div>
                </a>
            </div>
          
            <div class="col-lg-3 col-xs-6">
                <!-- small box -->
                <a href="<?php echo base_url();?>admin/case_information">
                    <div class="small-box bg-yellow">
                        <div class="inner">
                            <h3><?php echo $this->db->where('status',"Approved")->count_all_results('company_case');?></h3>
                            <p>Approved Cases</p>
                        </div>
                        <div class="icon">
                            <i class="fa fa-book"></i> 
                        </div>
                    </div>
                </a>
            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-xs-6">
                <!-- small box -->
                <a href="<?php echo base_url();?>admin/case_information" title="View All Pending Cases List">
                    <div class="small-box bg-red">
                        <div class="inner">
                            <h3><?php echo $this->db->where('status',"Pending")->count_all_results('company_case');?></h3>
                            <p>Pending Cases</p>
                        </div>
                        <div class="icon">
                            <i class="fa fa-book"></i>                    
                        </div>
                    </div>
                </a>
            </div>
            <!-- ./col -->
        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->
