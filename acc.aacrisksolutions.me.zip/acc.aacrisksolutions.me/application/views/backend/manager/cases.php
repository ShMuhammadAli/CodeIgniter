 <?php  if($feedback= $this->session->flashdata('feedback')):
                $feedback_class= $this->session->flashdata('feedback_class'); ?>

                <div class="alert alert-dismissible <?= $feedback_class ?>">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <h4><i class="icon fa fa-check"></i>
                        <?= $feedback ?>
                    </h4>    
                </div>
            <?php   endif; ?>
            <!-- /.box-header -->
<div class="row">
    <div class="col-xs-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title"><?php echo $title; ?></h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                     <tr>
                        <th>Manager Name</th>
                        <th>Case Title</th>
                        <th>Country</th>
                        <th>Company</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Type</th>
                        <th>Coments</th>
                        <th>Documents</th>
                        <th>Reference No</th>
                        <th>Option</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php
                         if (count($cases)):
                             foreach ($cases as $case): ?>
                            </tr>
                                <td> <?php echo $this->session->userdata('name'); ?></td>
                                <td><?php  echo $case->case_name;?></td>
                                <td><?php  echo $case->case_country;?></td>
                                <td> <?php echo $case->company_name; ?></td>
                                <td> <?php echo $case->case_date; ?></td>
                                <?php if($case->status == "Approved")
                                { $color="#0DE50D";}else{$color="#e50d0d";} ?>
                                <td style="color:<?php echo $color;?>"><?php  echo $case->status; ?></td>
                                <td><?php  echo $case->case_type_name; ?></td>
                                <td><?php  echo $case->case_comments; ?></td>
                                <td><a href="<?php echo $case->case_doc;?>" download=""> Download</a></td>
                                <td><?php echo $case->case_no;?></td>
                                <td>
                                    <div class="btn-group">
                                        <?php echo anchor("manager/edit_case/{$case->case_id}",'Edit',['class'=>'btn btn-primary ']); ?>
                                    </div>
                                </td>
                            </tr>    
                     <?php endforeach; endif; ?>
                    </tbody>
                    <tfoot>
                    <tr>
                        <th>Manager Name</th>
                        <th>Case Title</th>
                        <th>Country</th>
                        <th>Company</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Type</th>
                        <th>Coments</th>
                        <th>Documents</th>
                        <th>Reference No</th>
                        <th>Option</th>
                    </tr>
                    </tfoot>
                </table>
            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.box -->
    </div>
    <!-- /.col -->
</div>
