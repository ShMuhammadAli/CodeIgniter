<?php


class AdminModel extends CI_Model
{
	
	function __construct()
	{
		parent::__construct();
	}

	///////// Company /////////////
    function get_all_company() {

        $query = $this->db->get('company');
        return $query->result();
    }
    function get_company_data($company_id)
    {
        $query = $this->db->where('company_id',$company_id)->get('company');
            if ($query->num_rows() >0) {
                    
                    return  $query->row();
                }        
    }

    public function update_comopany($company_id,$data)
    {
        return    $this->db->set($data,FALSE)->where('company_id',$company_id)->update('company');
        
    }
    public function delete_company($company_id)
    {
        return $this->db->delete('company',['company_id'=>$company_id]);
    }

    ////////////////Cases Inforamtion Model/////////////////

    public function get_cases()
    {
        
        $this->db->select('ennovive.company_case.*,
                                ennovive.case_type.case_type_name');
        $this->db->from('case_type');
        $this->db->join('company_case','ennovive.company_case.case_type_id=ennovive.case_type.case_type_id');
        $query = $this->db->get();
        return $query->result();
    }
    public function get_case_data($case_id)
    {
        $query = $this->db->where('case_id',$case_id)->get('company_case');
            if ($query->num_rows() >0) {
                    
                    return  $query->row();
                }
    }
    public function update_case_status($case_id,$case_data)
    {
         return    $this->db->set($case_data,FALSE)->where('case_id',$case_id)->update('company_case');
    }

//////////////////// Get All Managers List ///////////////////
    public function get_all_managers()
    {
        $query = $this->db->get('managers');
        return $query->result();
    }

    public function edit_manger($manager_id)
    {
        $query = $this->db->where('manager_id',$manager_id)->get('managers');
            if ($query->num_rows() >0) {
                    
                    return  $query->row();
                }
    }
    public function update_manager($manager_id,$manager_data)
    {

        return    $this->db->set($manager_data,FALSE)->where('manager_id',$manager_id)->update('managers');
    }

    public function delete_manager($manager_id)
    {
        return $this->db->delete('managers',['manager_id'=>$manager_id]);
    }
// --------------------- Manager Compani Module ----------------------

    public function manager_companies()
    {
        $this->db->select(' ennovive.managers.manager_name,
                            ennovive.company.company_name,
                            ennovive.manager_company_case.mcs_id,
                            ennovive.manager_company_case.company_id,
                            ennovive.manager_company_case.manager_id');

        $this->db->from('ennovive.manager_company_case');

        $this->db->join('company','ennovive.manager_company_case.company_id =ennovive.company.company_id');
        $this->db->join('managers','ennovive.manager_company_case.manager_id = ennovive.managers.manager_id');
        $query = $this->db->get();
        return $query->result();
    }

    public function get_manger_company($mc_id)
    {
        $query = $this->db->where('mcs_id',$mc_id)->get('manager_company_case');
            if ($query->num_rows() >0) {
                    
                return  $query->row();
            }
    }

    public function update_manager_company($manager_company_data,$mc_id)
    {
        
        return   $this->db->set($manager_company_data,FALSE)->where('mcs_id',$mc_id)->update('manager_company_case');
    }
// mcs = manager company cases
    public function delete_manager_company($mcs_id)
    {
        return $this->db->delete('manager_company_case',['mcs_id'=>$mcs_id]);

    }
    public function update_admin_profile($admin_id,$data)
    {
         return   $this->db->set($data,FALSE)->where('admin_id',$admin_id)->update('admin');
    }





}
















?>