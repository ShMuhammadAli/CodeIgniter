
    <!-- Main content -->
    <section class="content">
        <!-- Small boxes (Stat box) -->
      <div class="row">
            <div class="col-lg-3 col-xs-6">
                <!-- small box -->
                <a href="http://localhost/ennovive/manager/company" title=" My All Company List">
                    <div class="small-box bg-aqua">
                        <div class="inner">
                           <h3>

                            <?php $id = $this->session->userdata('manager_id'); ?>

                            <?php echo $this->db->where('manager_id',$id)->count_all_results('manager_company_case');?></h3>
                            <p> My Companies</p>
                        </div>
                        <div class="icon">
                            <i class="fa fa-fw fa-users"></i>
                        </div>
                    </div>
                </a>
            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-xs-6">
                <!-- small box -->
                <a href="http://localhost/ennovive/manager/cases" title=" My All Cases List">
                    <div class="small-box bg-green">
                        <div class="inner">
                            <h3><?php 
                        echo    $this->db->select(' ennovive.company.company_id,
                                                ennovive.company_case.case_id,
                                                ennovive.manager_company_case.manager_id')
                                                ->from('ennovive.manager_company_case')
                                                ->join('ennovive.company', 'ennovive.manager_company_case.company_id = ennovive.company.company_id')
                                                ->join('ennovive.company_case', ' ennovive.company_case.company_id = ennovive.company.company_id')
                                                ->where('ennovive.manager_company_case.manager_id',$id)
                                                ->count_all('company_case');?></h3>
                            <p>My All Cases</p>
                        </div>
                        <div class="icon">
                              <i class="fa fa-book"></i>
                        </div>
                    </div>
                </a>
            </div>
          
            <div class="col-lg-3 col-xs-6">
                <!-- small box -->
                <a href="http://localhost/ennovive/manager/cases" title="Approved Cases">
                    <div class="small-box bg-yellow">
                        <div class="inner">
                            <h3><?php echo $this->db->where('status',"Approved")->count_all_results('company_case');?></h3>

                            <p>Approved Cases</p>
                        </div>
                        <div class="icon">
                            <i class="fa fa-book"></i> 
                        </div>
                    </div>
                </a>
            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-xs-6">
                <!-- small box -->
                <div class="small-box bg-red">
                    <div class="inner">
                        <h3><?php echo $this->db->where('status',"Pending")->count_all_results('company_case');?></h3>
                        <p>Pending Cases</p>
                    </div>
                    <div class="icon">
                        <i class="fa fa-book"></i>                    
                    </div>
                </div>
            </div>
            <!-- ./col -->
        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->
