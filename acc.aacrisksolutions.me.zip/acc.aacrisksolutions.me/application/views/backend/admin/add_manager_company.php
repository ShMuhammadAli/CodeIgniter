<div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8">
            <div class="box box-primary">
                <!-- form start -->
                <?php echo form_open_multipart('admin/manager_company/create',array('role'=>"form", 'class'=>'validate')); ?>

                    <div class="box-body">

                     <div class="form-group">
                            <label>Select Manager</label>
                            <select name="manager" class="form-control select2" style="width: 100%; height: auto;" required>
                                <option value selected disabled>Manager List</option>
                                <?php
                                $managers = $this->adminmodel->get_all_managers();
                                if (count($managers)) {
                                    foreach ($managers as $manager) { ?>

                                    <option value="<?php echo $manager->manager_id;?>"> <?php echo $manager->manager_name; ?> </option>

                                <?php }}?>
                            </select>
                    </div>   
    
                    <div class="form-group">
                            <label>Select Company</label>
                            <select name="company" class="form-control select2" style="width: 100%; height: auto;" required>
                                <option value selected disabled>Company List</option>
                                <?php
                                $companies = $this->adminmodel->get_all_company();
                                if (count($companies)) {
                                    foreach ($companies as $company) { ?>

                                    <option value="<?php echo $company->company_id;?>"> <?php echo $company->company_name; ?> </option>
                                <?php }}?>
                            </select>
                        </div>   
                    </div>
                    <div class="box-footer">
                        <button type="submit" class="btn btn-block btn-success btn-flat">Assign Company</button>
                    </div>
                    <?php echo form_close();?>
            </div>
            <!-- /.box -->

        </div>
    </div>
