<?php

class CompanyModel extends CI_Model
{
	
	function __construct()
	{
		parent::__construct();
	}
	public function index()
	{
		echo "CompanyModel";
	}
	public function company_case($company_id)
	{
		$this->db->select('ennovive.case_type.case_type_name,
    							ennovive.company_case.*');
        $this->db->from('ennovive.company_case');
        $this->db->join('ennovive.case_type','ennovive.company_case.case_type_id = ennovive.case_type.case_type_id');
        
        $this->db->join('ennovive.company','ennovive.company_case.company_id = ennovive.company.company_id');
        
        $this->db->where(array('ennovive.company_case.company_id'=> $company_id ));

        $query = $this->db->get();
		 if ($query->num_rows() > 0) {

		 	return $query->result(); 
		 	}
	}
	public function delete_case($case_id)
	{
		return $this->db->delete('company_case',array('case_id' => $case_id)); 

	}
	public function update_company_profile($company_id,$data)
	{
		return   $this->db->set($data,FALSE)->where('company_id',$company_id)->update('company');

	}
	
}

?>